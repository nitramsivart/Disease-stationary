#define PERSON_BUFFER 100
#define NUM_PEOPLE    5000
#define DAYS_INFECTED 10
#define EXP_PARAMETER 140.0

class World
{
public:
  typedef struct person {
    // 0 = Succeptible
    // 1 - 254 = Infected
    // 255 = Dead/safe/recovered
    char status;
    float x;
    float y;
  } person;

  World();
  virtual ~World();

  person* get_people();
  int print_people(person[]);
  int step();

private:
  person* generate_people(int);
  int populate_person(person *);
  int print_person(char *, person *);
  bool contact_occurs(person, person);
  float toroidal_distance(float, float, float, float);

  person* master_list;
};
